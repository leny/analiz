(function() {
  "use strict";
  var $, bTaskRunning, fDisplayResults, fFilesSelected, fLoadTasks, fRunTasks, fSelectTask, fToggleConfig, iTasksToRun, oFile, oTasks, pkg, sOSName;

  pkg = require("./package.json");

  sOSName = require("os-name")().toLowerCase().split(" ").join("");

  $ = require("jquery");

  oFile = null;

  oTasks = {};

  bTaskRunning = false;

  iTasksToRun = 0;

  fFilesSelected = function(e) {
    var aTasksToLoad;
    if (!(oFile = e.originalEvent.target.files[0])) {
      return;
    }
    $("#tasks ol").empty().toggleClass("loading", true);
    $("#files a").toggleClass("loaded", true).text(oFile.name);
    switch (oFile.type) {
      case "text/html":
        aTasksToLoad = ["html/validation", "html/lint"];
        break;
      default:
        console.log("no tasks for that kind of files.");
    }
    if (aTasksToLoad.length) {
      return fLoadTasks(aTasksToLoad);
    }
  };

  fLoadTasks = function(aGivenTasks) {
    var $element, $fieldset, $label, $task, $taskConfigForm, oFieldInfo, oFieldsets, oRadioInfo, oTask, sLegend, sName, sTask, _i, _j, _len, _len1, _ref, _ref1;
    oTasks = {};
    for (_i = 0, _len = aGivenTasks.length; _i < _len; _i++) {
      sTask = aGivenTasks[_i];
      oTasks[sTask] = (oTask = require("./js/tasks/" + sTask + ".js"));
      $task = $("<li><span><a href=\"#\" class=\"select\">" + oTask.infos.name + "</a></span></li>").attr("id", sTask);
      $("#tasks ol").append($task);
      if (oTask.infos.config && oTask.config) {
        $("<a />").addClass("config").attr("href", "#").attr("title", "edit configuration").appendTo($task.find("span"));
        $taskConfigForm = $("<form />");
        _ref = oTask.config;
        for (sLegend in _ref) {
          oFieldsets = _ref[sLegend];
          $fieldset = $("<fieldset><legend>" + sLegend + "</legend></fieldset>");
          for (sName in oFieldsets) {
            oFieldInfo = oFieldsets[sName];
            $element = $("<div />").addClass("form-elt");
            if (oFieldInfo.radio) {
              $element.addClass("multiple");
              $("<strong />").text(oFieldInfo.title).appendTo($element);
              _ref1 = oFieldInfo.values;
              for (_j = 0, _len1 = _ref1.length; _j < _len1; _j++) {
                oRadioInfo = _ref1[_j];
                $label = $("<label />").appendTo($element);
                $("<input />").attr("type", "radio").attr("name", sName).attr("value", oRadioInfo.value).prop("checked", !!oRadioInfo.checked).appendTo($label);
                $("<span />").text(oRadioInfo.title).appendTo($label);
                $("<p />").text(oRadioInfo.description).appendTo($label);
              }
            } else {
              $label = $("<label />").appendTo($element);
              $("<input />").attr("type", "checkbox").attr("name", sName).attr("value", oFieldInfo.value).prop("checked", !!oFieldInfo.checked).appendTo($label);
              $("<span />").text(oFieldInfo.title).appendTo($label);
              $("<p />").text(oFieldInfo.description).appendTo($label);
            }
            $element.appendTo($fieldset);
          }
          $fieldset.appendTo($taskConfigForm);
        }
        $taskConfigForm.appendTo($task);
      }
    }
    return $("#tasks ol").toggleClass("loading", false).find("li a.select").on("click", fSelectTask).end().find("li a.config").on("click", fToggleConfig);
  };

  fSelectTask = function(e) {
    e.preventDefault();
    return $(this).parents("li").toggleClass("selected");
  };

  fToggleConfig = function(e) {
    e.preventDefault();
    return $(this).parents("li").toggleClass("open");
  };

  fRunTasks = function(e) {
    var $link, $report, $reports, $tasks, dDate, iHours, iMinutes, iSeconds, sHours, sMinutes, sSeconds;
    e.preventDefault();
    if (bTaskRunning) {
      return;
    }
    if (!(iTasksToRun = ($tasks = $("#tasks li.selected")).size())) {
      return;
    }
    ($reports = $("div.right > ol")).find("li").removeClass("open").addClass("closed");
    $reports.addClass("loading");
    bTaskRunning = true;
    ($report = $("<li />")).addClass("open").appendTo($reports);
    ($link = $("<a />")).attr("href", "#").appendTo($report).on("click", function(e) {
      e.preventDefault();
      return $(this).parent().toggleClass("open").toggleClass("closed");
    });
    $("<strong />").text(oFile.path).appendTo($link);
    $("<em />").text(("" + iTasksToRun + " task") + (iTasksToRun > 1 ? "s" : "")).appendTo($link);
    dDate = new Date();
    sHours = (iHours = dDate.getHours()) < 10 ? "0" + iHours : iHours;
    sMinutes = (iMinutes = dDate.getMinutes()) < 10 ? "0" + iMinutes : iMinutes;
    sSeconds = (iSeconds = dDate.getSeconds()) < 10 ? "0" + iSeconds : iSeconds;
    $("<span />").text("" + sHours + ":" + sMinutes + ":" + sSeconds).appendTo($link);
    $("<ol />").appendTo($report);
    return $tasks.each(function() {
      var $config, aConfig, sID;
      sID = $(this).attr("id");
      if (($config = $(this).find("form")).size()) {
        aConfig = $config.serializeArray();
        return oTasks[sID].run(oFile, aConfig, fDisplayResults);
      } else {
        return oTasks[sID].run(oFile, fDisplayResults);
      }
    });
  };

  fDisplayResults = function($results) {
    var $report;
    ($report = $("div.right > ol")).children("li").last().children("ol").append($results);
    if (--iTasksToRun === 0) {
      bTaskRunning = false;
      return $report.removeClass("loading");
    }
  };

  $(function() {
    $("body").addClass(sOSName);
    $("#files a").on("click", function(e) {
      e.preventDefault();
      return $("#files input").trigger("click");
    });
    $("#files input").on("change", fFilesSelected);
    return $("#tasks .actions a").on("click", fRunTasks);
  });

}).call(this);
