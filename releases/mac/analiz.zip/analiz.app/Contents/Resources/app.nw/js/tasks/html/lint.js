(function() {
  "use strict";
  var $, fs, htmlhint, oInfos;

  htmlhint = require("htmlhint").HTMLHint;

  fs = require("fs");

  $ = require("jquery");

  exports.infos = oInfos = {
    name: "HTML Hint",
    config: true
  };

  exports.config = {
    "Standard": {
      "tagname-lowercase": {
        title: "Tagname lowercase",
        value: 1,
        checked: true,
        description: "Tagname must be lowercase."
      },
      "attr-lowercase": {
        title: "Attr lowercase",
        value: 1,
        checked: true,
        description: "Attribute name must be lowercase."
      },
      "attr-value-double-quotes": {
        title: "Attr value double quotes",
        value: 1,
        checked: true,
        description: "Attribute value must closed by double quotes."
      },
      "attr-value-not-empty": {
        title: "Attr value not empty",
        value: 1,
        description: "Attribute must set value."
      },
      "doctype-first": {
        title: "Doctype first",
        value: 1,
        description: "Doctype must be first."
      },
      "tag-pair": {
        title: "Tag par",
        value: 1,
        description: "Tag must be paired"
      },
      "tag-self-close": {
        title: "Tag self close",
        value: 1,
        description: "The empty tag must be closed by self"
      },
      "spec-char-escape": {
        title: "Tag self close",
        value: 1,
        description: "Special characters must be escaped."
      },
      "id-unique": {
        title: "ID unique",
        value: 1,
        description: "Id must be unique."
      },
      "src-not-empty": {
        title: "Src not empty",
        value: 1,
        description: "Src of img(script,link) must set value.\nEmpty src will visit current page twice."
      }
    },
    "Performance": {
      "head-script-disabled": {
        title: "Head script disabled",
        value: 1,
        description: "The script tag can not be used in head."
      }
    },
    "Accessibility": {
      "img-alt-require": {
        title: "Img alt require",
        value: 1,
        checked: true,
        description: "Alt of img tag must be set value."
      }
    },
    "Specification": {
      "doctype-html5": {
        title: "Doctype html5",
        value: 1,
        description: "Doctype must be html5."
      },
      "id-class-value": {
        title: "ID class value",
        radio: true,
        values: [
          {
            title: "none",
            value: 0,
            checked: true,
            description: "Id and class value doesn't need to follow some rules."
          }, {
            title: "underline",
            value: "underline",
            description: "Id and class value must meet some rules: underline_separated."
          }, {
            title: "dash",
            value: "dash",
            description: "Id and class value must meet some rules: dash-separated."
          }, {
            title: "camelCase",
            value: "hump",
            description: "Id and class value must meet some rules: camelCaseSeparated."
          }
        ]
      },
      "style-disabled": {
        title: "Style disabled",
        value: 1,
        description: "Style tag can not be use."
      }
    }
  };

  exports.run = function(oFile, aConfig, fNext) {
    var mValue, oConfig, oRules, _i, _len, _ref;
    oRules = {};
    for (_i = 0, _len = aConfig.length; _i < _len; _i++) {
      oConfig = aConfig[_i];
      oRules[oConfig.name] = (_ref = (mValue = oConfig.value)) === "1" || _ref === "0" ? !!mValue : mValue;
    }
    return fs.readFile(oFile.path, {
      encoding: "utf-8"
    }, function(oError, sRawHTML) {
      var $container, $counter, $list, $message, $report, aResults, oMessage, _j, _len1;
      aResults = htmlhint.verify(sRawHTML, oRules);
      $report = $("<li />");
      $("<strong />").text(oInfos.name).appendTo($report);
      ($container = $("<div />")).addClass("result").appendTo($report);
      if (aResults.length) {
        ($counter = $("<span />")).text(("" + aResults.length + " message") + (aResults.length > 1 ? "s" : "")).appendTo($container);
        ($list = $("<ol />")).appendTo($container);
        for (_j = 0, _len1 = aResults.length; _j < _len1; _j++) {
          oMessage = aResults[_j];
          ($message = $("<li />")).addClass("message").addClass(oMessage.subtype || oMessage.type).appendTo($list);
          $("<strong />").text(oMessage.subtype || oMessage.type).appendTo($message);
          $("<em />").addClass("line").text(oMessage.line).appendTo($message);
          $("<span />").text(oMessage.message).appendTo($message);
        }
      } else {
        $("<span />").addClass("no-message").text("no error").appendTo($container);
      }
      return fNext($report);
    });
  };

}).call(this);
