(function() {
  "use strict";
  var $, oInfos, w3cjs;

  w3cjs = require("w3cjs");

  $ = require("jquery");

  exports.infos = oInfos = {
    name: "W3C Validator",
    config: false
  };

  exports.run = function(oFile, fNext) {
    return w3cjs.validate({
      file: oFile.path,
      callback: function(oResponse) {
        var $container, $counter, $list, $message, $report, oMessage, _i, _len, _ref;
        $report = $("<li />");
        $("<strong />").text(oInfos.name).appendTo($report);
        ($container = $("<div />")).addClass("result").appendTo($report);
        if (oResponse.messages && oResponse.messages.length) {
          ($counter = $("<span />")).text(("" + oResponse.messages.length + " message") + (oResponse.messages.length > 1 ? "s" : "")).appendTo($container);
          ($list = $("<ol />")).appendTo($container);
          _ref = oResponse.messages;
          for (_i = 0, _len = _ref.length; _i < _len; _i++) {
            oMessage = _ref[_i];
            ($message = $("<li />")).addClass("message").addClass(oMessage.subtype || oMessage.type).appendTo($list);
            $("<strong />").text(oMessage.subtype || oMessage.type).appendTo($message);
            $("<em />").addClass("line").text(oMessage.lastLine).appendTo($message);
            $("<span />").text(oMessage.message).appendTo($message);
          }
        } else {
          $("<span />").addClass("no-message").text("no error").appendTo($container);
        }
        return fNext($report);
      }
    });
  };

}).call(this);
